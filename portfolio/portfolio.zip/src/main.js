/* Feather icons */
feather.replace()

/* AOS */
AOS.init();